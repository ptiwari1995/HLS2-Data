08-30-2021

- Changed concept ids to query for HLS v2.0
- Updated readme dates to query granules from the month of July 2021. HLS v2.0 currently does not have granules available for earlier dates.
